from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from booking import Booking
# from Bookings import Booking
import Ui_Qrcode
import Ui_Show_Qr
import ZODB, ZODB.FileStorage, ZODB.DB, persistent, BTrees.OOBTree, transaction
import Ui_Manage2
import sys
import pyqrcode


class Manage_Window(QWidget):
    # class constructor
    def __init__(self,user):
        # call QWidget constructor
        super().__init__()
        self.__currentUser = user
        self.ui = Ui_Manage2.Ui_Form()
        self.ui.setupUi(self)
        self.ui.frame.hide()
        self.displayBookings()
        self.ui.delete_btn.setEnabled(False)
        self.ui.change_btn.setEnabled(False)
        # # set control_bt callback clicked  function
        # self.ui.scan_btn.clicked.connect(self.controlTimer)
        # self.ui.cancel_btn.clicked.connect(self.stopTimer)
        self.ui.add_btn.clicked.connect(self.add)
        self.ui.change_btn.clicked.connect(self.change)
        self.ui.delete_btn.clicked.connect(self.delete)
        self.ui.book_btn.clicked.connect(self.book)

        self.ui.tableWidget.selectionModel().selectionChanged.connect(self.on_selectionChanged)
        # self.dateTimeEdit_in.dateTimeChanged['QDateTime'].connect(self.dateTimeEdit_out.setDateTime)

 #----------------------------------       

    def displayBookings(self):
        # book1 = Booking("12/05/2004","12:00","13:00")
        # book2 = Booking("13/05/2004","12:00","13:00")

        storage = ZODB.FileStorage.FileStorage('bookingsDB.fs')
        db = ZODB.DB(storage)
        connection = db.open()
        root = connection.root()
        # root[self.__currentUser]=[]
        # root[self.__currentUser].append(book1)
        # root[self.__currentUser].append(book2)
        # transaction.commit()
        for booking in root[self.__currentUser]:
            # print(booking)
            self.ui.tableWidget.insertRow ( self.ui.tableWidget.rowCount() )
            self.ui.tableWidget.setItem( self.ui.tableWidget.rowCount()-1, 0, QTableWidgetItem(str(booking.getDate())))
            self.ui.tableWidget.setItem( self.ui.tableWidget.rowCount()-1, 1, QTableWidgetItem(str(booking.getStartTime())))
            self.ui.tableWidget.setItem( self.ui.tableWidget.rowCount()-1, 2, QTableWidgetItem(str(booking.getEndTime())))

        connection.close()
        db.close()

    def reset_value(self):
        self.ui.book_btn.setText('Book')
        self.ui.dateTimeEdit_in.clear()
        self.ui.dateTimeEdit_out.clear()
        # self.ui.tableWidget.clearContents()
        while self.ui.tableWidget.rowCount()!=0:
            self.ui.tableWidget.removeRow(0)
        self.ui.tableWidget.clear()
    def add(self):
        self.ui.frame.show()


    def change(self):
        #Set Qtime edit equal to that select row
        self.set_selected_time_edit()
        self.ui.book_btn.setText('Change')
        self.ui.frame.show()
        # date = select_row[0].text()
        # time_in = select_row[1].text()
        # time_out = select_row[2].text()

            
    def delete(self):
        self.set_selected_time_edit()
        self.ui.book_btn.setText('Delete')
        #Set Qtime edit equal to that select row
        # select_row = int(selected.indexes()[0].row())
        self.ui.frame.show()

    def book(self):
        storage = ZODB.FileStorage.FileStorage('bookingsDB.fs')
        db = ZODB.DB(storage)
        connection = db.open()
        root = connection.root()
        flag = False
        bookingList = root[self.__currentUser]
        if self.ui.book_btn.text()=='Book':
            time_in = self.ui.dateTimeEdit_in.dateTime()
            time_in = time_in.toString('M/d/yyyy hh:mm ').split()

            time_out = self.ui.dateTimeEdit_out.dateTime()
            time_out = time_out.toString('M/d/yyyy hh:mm ').split()
            # print(time_in)
            #Validate the date time in and out with the previous booking too
            new_booking = Booking(time_in[0],time_in[1],time_out[1])
            key = new_booking.get_key()
            self.gen_QR(key)
            flag = True
            bookingList.append(new_booking)

        elif self.ui.book_btn.text() == 'Change':
            select_row = self.ui.tableWidget.currentRow()
            time_in = self.ui.dateTimeEdit_in.dateTime()
            time_in = time_in.toString('M/d/yyyy hh:mm ').split()

            time_out = self.ui.dateTimeEdit_out.dateTime()
            time_out = time_out.toString('M/d/yyyy hh:mm ').split()

            #Validate the datem time in and out with the data base
            select_booking = bookingList[select_row]
            select_booking.setDate(time_in[0])
            select_booking.setTimeIn(time_in[1])
            select_booking.setTimeOut(time_out[1])
            key = select_booking.get_key()
            self.gen_QR(key)
            flag = True
            bookingList[select_row] = select_booking
        elif self.ui.book_btn.text() == 'Delete':
            select_row = self.ui.tableWidget.currentRow()
            bookingList = bookingList.remove(select_row)
        root[self.__currentUser] = bookingList
        transaction.commit()
        connection.close()
        db.close()
        # msg = QMessageBox()
        # msg.setWindowTitle('Completed')
        # msg.setText('You action Success!')
        # msg.setIconPixmap(QPixmap("QR_CODE.png"));
        # msg.exec_()
        self.Form = QtWidgets.QWidget()
        ui = Ui_Show_Qr.Ui_Dialog(flag)
        ui.setupUi(self.Form)
        self.Form.show()

        self.ui.frame.hide()
        self.reset_value()
        self.displayBookings()

    def on_selectionChanged(self,selected,dselected):
        print(selected)
        self.ui.delete_btn.setEnabled(True)
        self.ui.change_btn.setEnabled(True)       
        # for index in selected.indexes():
        #     print(index.row())
        # print(selected.indexes()[0].row())
        # select_row = int(selected.indexes()[0].row())
        # select_row = self.ui.tableWidget.selectedItems()
        # date = select_row[0].text()
        # time_in = select_row[1].text()
        # time_out = select_row[1].text()
        # day,month,year = [int(x) for x in date.split('/')]
        # h1,m1 = [int(x) for x in time_in.split(':')]
        # h2,m2 = [int(x) for x in time_out.split(':')]
        # d = QDate(year,month,day)
        # t1 = QDateTime(d,QTime(h1,m1))
        # t2 = QDateTime(d,QTime(h2,m2))
        # self.ui.dateTimeEdit_in.setDateTime(t1)
        # self.ui.dateTimeEdit_out.setDateTime(t2)
    def set_selected_time_edit(self):
        select_row = self.ui.tableWidget.selectedItems()
        date = select_row[0].text()
        time_in = select_row[1].text()
        time_out = select_row[1].text()
        day,month,year = [int(x) for x in date.split('/')]
        h1,m1 = [int(x) for x in time_in.split(':')]
        h2,m2 = [int(x) for x in time_out.split(':')]
        d = QDate(year,month,day)
        t1 = QDateTime(d,QTime(h1,m1))
        t2 = QDateTime(d,QTime(h2,m2))
        self.ui.dateTimeEdit_in.setDateTime(t1)
        self.ui.dateTimeEdit_out.setDateTime(t2)

    def gen_QR(self,key):
        print(key)
        qr_code = pyqrcode.create(key, mode='binary')
        qr_code.png('QR_CODE.png')
        return




if __name__ == '__main__':
    app = QApplication(sys.argv)
    # storage = ZODB.FileStorage.FileStorage('bookingsDB.fs')
    # db = ZODB.DB(storage)
    # connection = db.open()
    # root = connection.root()

    # transaction.commit()
    # connection.close()
    # db.close()
    # create and show mainWindow
    mainWindow = Manage_Window("User")
    mainWindow.show()

    sys.exit(app.exec_())
